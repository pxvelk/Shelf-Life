import React from 'react';

const cardContext = React.createContext({cardId: ""});

export { cardContext };